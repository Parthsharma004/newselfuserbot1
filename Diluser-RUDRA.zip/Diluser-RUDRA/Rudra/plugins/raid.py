
__NAME__ = "Raid"
__MENU__ = f"""
**Activate Shayari Raid On Any
Telegram User ...**

`.lraid` - Reply This Command
To Target User Message.

`.dlraid` - To Deactivate Just
Reply This Command.

**😋 Lraid Shortcut Command:**
=> [`.lr`, `.dlr`]"""
