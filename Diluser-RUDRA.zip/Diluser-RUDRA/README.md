<h2>Rudra-Userbot</h2>
<p title="RUDRA-JAAT">Rudra is a powerful, advanced, multi-featured Telegram userbot.</p>

<p align="center"><a href="https://t.me/RUDRA_JAAT"><img src="https://mallucampaign.in/images/img_1693670648.jpg"></a></p>

![](Rudra/resorce/maintained.svg)
![](Rudra/resource/license.svg)

<h2>Deployment</h2>
<p title="Deployment">You can use Rudra-Userbot through the cloud application platform Heroku.</p>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/RUDRA-JAAT/Rudra-User-Bot)

Or, simply run the following commands in your Vps,

1. At first enter this command and wait untill complete.
```
sudo apt update && sudo apt install git curl nano screen python3-pip ffmpeg -y && curl https://raw.githubusercontent.com/creationix/nvm/master/install.sh | bash && source ~/.bashrc && nvm install node
```

2. Now simply copy and paste this command and wait.
```
sudo rm -rf Rudra && git clone https://github.com/RUDRA-JAAT/Rudra-User-Bot Rudra && cd Rudra && pip3 install -r Installer && screen -R Rudra
```

4. After that, Enter this command and put your vars and hit ```ctrl+s``` to save and hit ```ctrl+x``` To Close Text Editor.
```
nano Internal.env
```

6. Now enter this command and wait untill run your userbot.
```
cp Internal.env Internal && python3 -m Rudra
```

8. Finnally, just hit ```ctrl+a+d``` to minimize your bot for run in background.


<p align="center">
<a href="https://telegram.me/RUDRA_JAAT"><img src="https://img.shields.io/badge/-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

<p align="center">
<a href="https://telegram.me/RUDRA_JAAT"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>


